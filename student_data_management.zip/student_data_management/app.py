import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

DB_NAME = "students.db"

def connect_db():
    return sqlite3.connect(DB_NAME)

def setup_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER,
                course TEXT,
                email TEXT,
                phone TEXT
            )
        """)

def refresh_table():
    for item in tree.get_children():
        tree.delete(item)
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT id, name, age, course, email, phone FROM students ORDER BY id DESC"
        ).fetchall()
    for row in rows:
        tree.insert("", tk.END, values=row)

def clear_fields():
    for field in (name_var, age_var, course_var, email_var, phone_var):
        field.set("")
    tree.selection_remove(tree.selection())

def add_student():
    name = name_var.get().strip()
    if not name:
        messagebox.showwarning("Missing information", "Please enter the student's name.")
        return
    try:
        age = int(age_var.get()) if age_var.get().strip() else None
        if age is not None and not 1 <= age <= 120:
            raise ValueError
    except ValueError:
        messagebox.showwarning("Invalid age", "Enter a valid age between 1 and 120.")
        return
    with connect_db() as conn:
        conn.execute(
            "INSERT INTO students (name, age, course, email, phone) VALUES (?, ?, ?, ?, ?)",
            (name, age, course_var.get().strip(), email_var.get().strip(), phone_var.get().strip())
        )
    refresh_table()
    clear_fields()
    messagebox.showinfo("Saved", "Student record added successfully.")

def select_student(_event=None):
    selected = tree.selection()
    if not selected:
        return
    values = tree.item(selected[0], "values")
    name_var.set(values[1])
    age_var.set(values[2])
    course_var.set(values[3])
    email_var.set(values[4])
    phone_var.set(values[5])

def update_student():
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Select record", "Select a student record to update.")
        return
    name = name_var.get().strip()
    if not name:
        messagebox.showwarning("Missing information", "Student name is required.")
        return
    try:
        age = int(age_var.get()) if age_var.get().strip() else None
        if age is not None and not 1 <= age <= 120:
            raise ValueError
    except ValueError:
        messagebox.showwarning("Invalid age", "Enter a valid age between 1 and 120.")
        return
    student_id = tree.item(selected[0], "values")[0]
    with connect_db() as conn:
        conn.execute(
            "UPDATE students SET name=?, age=?, course=?, email=?, phone=? WHERE id=?",
            (name, age, course_var.get().strip(), email_var.get().strip(), phone_var.get().strip(), student_id)
        )
    refresh_table()
    clear_fields()
    messagebox.showinfo("Updated", "Student record updated successfully.")

def delete_student():
    selected = tree.selection()
    if not selected:
        messagebox.showwarning("Select record", "Select a student record to delete.")
        return
    if not messagebox.askyesno("Confirm delete", "Delete the selected student record?"):
        return
    student_id = tree.item(selected[0], "values")[0]
    with connect_db() as conn:
        conn.execute("DELETE FROM students WHERE id=?", (student_id,))
    refresh_table()
    clear_fields()

def search_students():
    keyword = search_var.get().strip()
    for item in tree.get_children():
        tree.delete(item)
    with connect_db() as conn:
        rows = conn.execute(
            """SELECT id, name, age, course, email, phone FROM students
               WHERE name LIKE ? OR course LIKE ? OR email LIKE ?
               ORDER BY id DESC""",
            (f"%{keyword}%", f"%{keyword}%", f"%{keyword}%")
        ).fetchall()
    for row in rows:
        tree.insert("", tk.END, values=row)

root = tk.Tk()
root.title("Student Data Management System")
root.geometry("1000x650")
root.minsize(850, 560)
root.configure(bg="#f2f5f9")

title = tk.Label(root, text="STUDENT DATA MANAGEMENT SYSTEM",
                 font=("Arial", 20, "bold"), bg="#183153", fg="white", pady=16)
title.pack(fill=tk.X)

form = tk.Frame(root, bg="#f2f5f9", padx=20, pady=18)
form.pack(fill=tk.X)

name_var, age_var = tk.StringVar(), tk.StringVar()
course_var, email_var, phone_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
search_var = tk.StringVar()

fields = [
    ("Student Name", name_var), ("Age", age_var),
    ("Course", course_var), ("Email", email_var), ("Phone", phone_var)
]
for index, (label, variable) in enumerate(fields):
    row, col = divmod(index, 3)
    tk.Label(form, text=label, bg="#f2f5f9", font=("Arial", 10, "bold")).grid(
        row=row*2, column=col, sticky="w", padx=8, pady=(5, 2))
    tk.Entry(form, textvariable=variable, font=("Arial", 11), width=30).grid(
        row=row*2+1, column=col, sticky="ew", padx=8, pady=(0, 8), ipady=5)
for col in range(3):
    form.grid_columnconfigure(col, weight=1)

buttons = tk.Frame(root, bg="#f2f5f9", padx=20)
buttons.pack(fill=tk.X, pady=4)
for label, command in [
    ("Add Student", add_student), ("Update", update_student),
    ("Delete", delete_student), ("Clear", clear_fields)
]:
    tk.Button(buttons, text=label, command=command, bg="#245b8f", fg="white",
              activebackground="#183153", activeforeground="white",
              font=("Arial", 10, "bold"), padx=15, pady=8, relief=tk.FLAT).pack(
                  side=tk.LEFT, padx=5)

search_frame = tk.Frame(root, bg="#f2f5f9", padx=25, pady=12)
search_frame.pack(fill=tk.X)
tk.Label(search_frame, text="Search by name, course or email:",
         bg="#f2f5f9", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=(0, 8))
tk.Entry(search_frame, textvariable=search_var, font=("Arial", 11), width=35).pack(side=tk.LEFT, ipady=4)
tk.Button(search_frame, text="Search", command=search_students, bg="#32734a",
          fg="white", font=("Arial", 10, "bold"), padx=14, pady=6, relief=tk.FLAT).pack(side=tk.LEFT, padx=8)
tk.Button(search_frame, text="Show All", command=refresh_table, font=("Arial", 10),
          padx=12, pady=6).pack(side=tk.LEFT)

table_frame = tk.Frame(root, padx=20, pady=10)
table_frame.pack(fill=tk.BOTH, expand=True)
columns = ("ID", "Name", "Age", "Course", "Email", "Phone")
tree = ttk.Treeview(table_frame, columns=columns, show="headings")
widths = (55, 180, 60, 150, 240, 140)
for col, width in zip(columns, widths):
    tree.heading(col, text=col)
    tree.column(col, width=width, anchor=tk.CENTER)
scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
tree.configure(yscrollcommand=scrollbar.set)
tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
tree.bind("<<TreeviewSelect>>", select_student)

setup_db()
refresh_table()
root.mainloop()
