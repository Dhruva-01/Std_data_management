STUDENT DATA MANAGEMENT SYSTEM

Features
- Add student records
- View all student records
- Update selected records
- Delete selected records
- Search by student name, course, or email
- Automatically stores data in a local SQLite database (students.db)

Requirements
- Python 3.9 or later
- Tkinter (usually included with standard Python on Windows)

How to run in VS Code
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: python app.py
5. The application window will open.

Database
The file students.db is created automatically in the project folder when the app runs.
Keep this file to retain your student records.

Note
This is a learning/demo project. Use sample data while testing.
